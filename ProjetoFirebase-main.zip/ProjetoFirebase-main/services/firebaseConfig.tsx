// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBe47kVdQhKzRQI4f-wMXiMNiQu6e3yqVI",
  authDomain: "projetofirebase-d05f4.firebaseapp.com",
  projectId: "projetofirebase-d05f4",
  storageBucket: "projetofirebase-d05f4.firebasestorage.app",
  messagingSenderId: "803155558391",
  appId: "1:803155558391:web:86359451ce02d9d44738f2",
  measurementId: "G-PDEWS85NHL"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);