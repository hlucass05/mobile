[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/aX0T4Rqv)
# Desafio: Implementação da Funcionalidade de Favoritar e Avaliar Filmes

## Descrição do Projeto

Este projeto é um aplicativo de filmes que exibe as informações mais recentes e populares do mundo do cinema. O aplicativo apresenta as seguintes seções:

- **Trending Movies**: Mostra um único filme que está em alta no momento.
- **Upcoming Movies**: Exibe uma lista de filmes que serão lançados em breve.
- **Top Rated Movies**: Apresenta uma lista de filmes com as melhores classificações.

## Desafio

Seu desafio é implementar duas funcionalidades no aplicativo:

1. **Favoritar filmes**: os usuários devem ser capazes de marcar/desmarcar filmes como favoritos e visualizar a lista de filmes favoritados.

2. **Avaliar filmes**: os usuários poderão escrever uma avaliação (review) para qualquer filme, preenchendo um pequeno formulário com seu nome e a opinião.

### Pré-requisito

- **Adicionar Nome e RM**

Antes de iniciar o desenvolvimento, adicione seu nome completo e número de RM na tela inicial do aplicativo.

### Funcionalidades a serem implementadas

1. **Favoritar Filmes**
   - Permitir que o usuário marque ou desmarque um filme como favorito.
   - A interface deve refletir visualmente o estado atual do favorito (ex: ícone preenchido/vazio).

2. **Exibir Filmes Favoritos**
   - Exibir todos os filmes que foram marcados como favoritos na tela principal.

3. **Persistência dos Favoritos**
   - Os filmes favoritados devem ser armazenados localmente utilizando `AsyncStorage`, garantindo que continuem disponíveis mesmo após o app ser fechado e reaberto.

4. **Adicionar Avaliação ao Filme**
   - Permitir que o usuário acesse uma tela ou modal onde possa preencher um formulário simples contendo:
     - Nome
     - Avaliação (texto livre)
   - As avaliações podem ser salvas temporariamente em memória (estado da aplicação), ou de forma persistente, se preferir um desafio adicional.
   - Validação obrigatória do formulário.

## Dicas Adicionais

- Sinta-se à vontade para consultar a documentação do React Native e outras bibliotecas que você está utilizando.
- Se necessário, utilize comentários no código para explicar partes importantes da lógica implementada.
- Tente manter o código limpo e bem organizado.

## Entrega

### Regras de Submissão - Commits e Pushes

Durante a realização do checkpoint, os seguintes procedimentos de versionamento
de código devem ser seguidos **rigorosamente**:

- **_Commits_ e _pushes_ a cada 15 minutos**:
  - É **obrigatório** realizar pelo menos **um commit** no repositório local e
    **um push** para o repositório remoto a cada **15 minutos** durante o checkpoint.
  - O commit deve refletir o progresso do código até aquele momento e ser
    acompanhado de uma mensagem descritiva e clara.

- **Proibição de `git push --force`**:
  - **Não é permitido** o uso do comando `git push --force` ou qualquer variação
    que force a sobrescrita do histórico de commits. Isso resultará em **penalidades**.

## 🚫 Penalidades

| Código                                               | Descrição                                                                                                                                                          | Penalidade                  |
| ---------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ | --------------------------- |
| ❌ **Solução feita pela IA**                         | A solução entregue foi criada integralmente por uma IA, sem participação ativa do aluno. Fere o princípio de aprendizado genuíno e independência na implementação. | Nota 0                      |
| 🚫 **Git Push Force**                                | Uso de `git push --force` ou qualquer sobrescrita de histórico.                                                                                                    | Nota 0                      |
| 🧩 **Uso de Conceitos ou Ferramentas Não Ensinadas** | O aluno utilizou bibliotecas, hooks, componentes ou ferramentas não abordadas durante a aula ou não previamente autorizadas.                                       | Desclassificação da entrega |
| 🤖 **Uso Indevido de IA**                            | Código copiado ou gerado integralmente por IA sem envolvimento ativo do aluno.                                                                                     | Nota 0                      |
| 🕓 **Commits Incompatíveis**                         | Histórico de commits não reflete a evolução real da solução (commits únicos, genéricos ou ausentes).                                                               | Penalização proporcional    |

Quando finalizar a implementação, envie um push com suas alterações.

Boa sorte e divirta-se programando!

## Screenshots

![Tela 1](./assets/screenshot_1.jpg)
![Tela 2](./assets/screenshot_2.jpg)
![Tela 3](./assets/screenshot_3.jpg)
![Tela 4](./assets/screenshot_4.jpg)
