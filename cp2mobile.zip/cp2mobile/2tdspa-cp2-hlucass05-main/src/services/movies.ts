import { topRatedData } from "@/data/top-rated";
import { trendingMoviewsData } from "@/data/trending";
import { upcomingData } from "@/data/upcoming";
import { Movie } from "@/types/movie";

const delay = 1_000;

export async function getTrendingMovie(): Promise<Movie> {
  const movies = await getTrendingMovies(1);
  return movies[0];
}

export async function getTrendingMovies(quantity: number): Promise<Movie[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const data = trendingMoviewsData.slice(0, quantity);
      resolve(data);
    }, delay);
  });
}

export async function getUpcomingMovies(quantity: number): Promise<Movie[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const data = upcomingData.slice(0, quantity);
      resolve(data);
    }, delay);
  });
}

export async function getTopRatedMovies(quantity: number): Promise<Movie[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const data = topRatedData.slice(0, quantity);
      resolve(data);
    }, delay);
  });
}

export async function getMovieDetail(id: number): Promise<Movie | null> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const trendingMovie = trendingMoviewsData.find((item) => item.id === id);

      if (trendingMovie) return resolve(trendingMovie);

      const upcomingMovie = upcomingData.find((item) => item.id === id);

      if (upcomingMovie) return resolve(upcomingMovie);

      const topRatedMoview = topRatedData.find((item) => item.id === id);

      if (topRatedMoview) return resolve(topRatedMoview);

      resolve(null);
    }, delay);
  });
}

export async function getSimilarMovies(
  movie: Movie,
  quantity: number,
): Promise<Movie[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const genreId = movie.genre_ids[0];

      const items1 = upcomingData.filter(
        (item) => item.id !== movie.id && item.genre_ids.includes(genreId),
      );
      const items2 = trendingMoviewsData.filter(
        (item) => item.id !== movie.id && item.genre_ids.includes(genreId),
      );
      const items3 = topRatedData.filter(
        (item) => item.id !== movie.id && item.genre_ids.includes(genreId),
      );

      const similarMovies = [...items1, ...items2, ...items3];
      const unique = similarMovies.filter(
        (movie, index, self) =>
          index === self.findIndex((p) => p.id === movie.id),
      );

      resolve(unique.sort(() => Math.random() - 0.5).slice(0, quantity));
    }, delay);
  });
}

export async function getMovieById(id: number) {
  try {
    const response = await fetch(`https://api.themoviedb.org/3/movie/${id}?language=en-US`, {
      headers: {
        Authorization: `Bearer ${process.env.EXPO_PUBLIC_TMDB_API_KEY}`,
        accept: "application/json",
      },
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Erro ao buscar filme por ID:", error);
    return null;
  }
}
