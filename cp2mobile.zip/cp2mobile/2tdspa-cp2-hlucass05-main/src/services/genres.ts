import { genres } from "@/data/genre";
import { Genre } from "@/types/genre";

export function getGenre(id: number): Genre {
  const genre = genres.find((item) => item.id === id);
  if (!genre) {
    throw new Error(`Genre with id ${id} not found`);
  }
  return genre;
}

export function getGenres(ids: number[]): Genre[] {
  return ids.map((id) => getGenre(id));
}
