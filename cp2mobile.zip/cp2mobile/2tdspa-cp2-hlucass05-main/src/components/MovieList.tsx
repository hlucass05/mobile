import { Link } from "expo-router";
import {
  Dimensions,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Movie } from "../types/movie";

const dimensions = Dimensions.get("window");

type Props = {
  title: string;
  data: Movie[];
  hideSeeAll?: boolean;
};

const MovieList = ({ title, data, hideSeeAll }: Props) => {
  if (!data || data.length === 0) {
    return null;
  }

  return (
    <View className="mb-8 gap-y-4">
      <View className="m-4 flex-row justify-between items-center">
        <Text className="text-white text-xl">{title}</Text>
        {!hideSeeAll && (
          <TouchableOpacity>
            <Text className="text-lg text-primary">See all</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 15 }}
      >
        {data.map((item, index) => {
          return (
            <Link
              href={{ pathname: "/movie/[id]", params: { id: item.id } }}
              key={index}
              className="gap-y-1 mr-4"
              asChild
            >
              <Pressable>
                <Image
                  source={{
                    uri: `https://image.tmdb.org/t/p/w342${item.poster_path}`,
                  }}
                  className="rounded-3xl"
                  style={localStyles.image}
                />
                <Text
                  style={localStyles.text}
                  numberOfLines={1}
                  className="text-neutral-300 mml-1"
                >
                  {item.title}
                </Text>
              </Pressable>
            </Link>
          );
        })}
      </ScrollView>
    </View>
  );
};

export default MovieList;

const localStyles = StyleSheet.create({
  image: {
    width: dimensions.width * 0.33,
    height: dimensions.height * 0.22,
  },
  text: {
    width: dimensions.width * 0.33,
  },
});
