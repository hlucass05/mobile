import { useCallback, useState } from "react";
import { useFocusEffect } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import MovieList from "./MovieList";
import { Movie } from "@/types/movie";
import { Text, View } from "react-native";

const STORAGE_KEY = "@favorites";

export default function MyFavorites() {
  const [data, setData] = useState<Movie[]>([]);

  const load = useCallback(async () => {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    setData(raw ? JSON.parse(raw) : []);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  if (data.length === 0) {
    return (
      <View className="px-4 mt-2 mb-4">
        <Text className="text-white text-lg font-semibold mb-2">My favorites</Text>
        <Text className="text-neutral-400">Você ainda não favoritou nenhum filme.</Text>
      </View>
    );
  }

  return <MovieList title="My favorites" data={data} hideSeeAll />;
}
