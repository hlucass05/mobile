import { Movie } from "@/types/movie";
import { Link } from "expo-router";
import { Dimensions, Image, Pressable, StyleSheet } from "react-native";

const { width, height } = Dimensions.get("window");

type Props = {
  item: Movie;
};

const MovieCard = ({ item }: Props) => {
  const imagePath = `https://image.tmdb.org/t/p/w342${item.poster_path}`;

  return (
    <Link href={{ pathname: "/movie/[id]", params: { id: item.id } }} asChild>
      <Pressable>
        <Image
          source={{ uri: imagePath }}
          style={styles.image}
          className="rounded-3xl"
        />
      </Pressable>
    </Link>
  );
};

export default MovieCard;

const styles = StyleSheet.create({
  image: {
    width: width * 0.6,
    height: height * 0.4,
  },
});
