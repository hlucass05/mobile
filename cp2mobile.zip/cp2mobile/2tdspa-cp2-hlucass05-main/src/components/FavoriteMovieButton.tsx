import Ionicons from "@expo/vector-icons/Ionicons";
import { Pressable } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";
import { Movie } from "@/types/movie";

type Props = { movie: Movie | null };

const STORAGE_KEY = "@favorites";

export default function FavoriteMovieButton({ movie }: Props) {
  const [isFavorite, setIsFavorite] = useState(false);

  useEffect(() => {
    (async () => {
      if (!movie) return;
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      const list: Movie[] = raw ? JSON.parse(raw) : [];
      setIsFavorite(list.some((m) => m.id === movie.id));
    })();
  }, [movie?.id]);

  const toggle = async () => {
    if (!movie) return;
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const list: Movie[] = raw ? JSON.parse(raw) : [];
    let next: Movie[];

    if (list.some((m) => m.id === movie.id)) {
      next = list.filter((m) => m.id !== movie.id);
      setIsFavorite(false);
    } else {
      next = [movie, ...list];
      setIsFavorite(true);
    }
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  };

  return (
    <Pressable onPress={toggle} hitSlop={10}>
      <Ionicons name={isFavorite ? "heart" : "heart-outline"} size={28} color="white" />
    </Pressable>
  );
}
