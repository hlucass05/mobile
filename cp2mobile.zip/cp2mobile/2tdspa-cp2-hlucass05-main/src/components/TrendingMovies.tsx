import { Movie } from "@/types/movie";
import React from "react";
import { Text, View } from "react-native";
import MovieCard from "./MovieCard";

type Props = {
  data: Movie | undefined;
};

const TrendingMovies = ({ data }: Props) => {
  if (!data) {
    return null;
  }

  return (
    <View className="mb-8 items-center">
      <Text className="text-white self-start text-xl mx-4 mb-5">Trending</Text>

      <MovieCard item={data} />
    </View>
  );
};

export default TrendingMovies;
