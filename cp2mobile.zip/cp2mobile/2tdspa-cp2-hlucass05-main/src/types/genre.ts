export interface Genre {
  id: number;
  name: string;
}
