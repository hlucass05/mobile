import { View, Text, TextInput, Button, ScrollView, Alert } from "react-native";
import { useLocalSearchParams, useNavigation } from "expo-router";
import { useEffect, useLayoutEffect, useState } from "react";
import { getMovieById } from "@/services/movies";
import { Movie } from "@/types/movie";
import FavoriteMovieButton from "@/components/FavoriteMovieButton";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "@reviews";

const reviewSchema = z.object({
  name: z.string().min(1, "Digite seu nome"),
  comment: z.string().min(1, "Digite um comentário"),
});

type Review = z.infer<typeof reviewSchema>;

export default function MovieDetail() {
  const { id } = useLocalSearchParams();
  const navigation = useNavigation();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<Review>({
    resolver: zodResolver(reviewSchema),
  });

  useEffect(() => {
    (async () => {
      const data = await getMovieById(Number(id));
      setMovie(data);

      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      const allReviews: Record<number, Review[]> = raw ? JSON.parse(raw) : {};
      setReviews(allReviews[Number(id)] || []);
    })();
  }, [id]);

  useLayoutEffect(() => {
    navigation.setOptions({
      title: movie ? movie.title : "Detalhes",
      headerRight: () => <FavoriteMovieButton movie={movie} />,
    });
  }, [navigation, movie]);

  const onSubmit = async (data: Review) => {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const allReviews: Record<number, Review[]> = raw ? JSON.parse(raw) : {};

    const currentMovieReviews = allReviews[Number(id)] || [];
    const newList = [data, ...currentMovieReviews];
    allReviews[Number(id)] = newList;

    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(allReviews));
    setReviews(newList);
    reset();

    Alert.alert("Sucesso", "Avaliação enviada!");
  };

  if (!movie) {
    return (
      <View className="flex-1 justify-center items-center bg-neutral-800">
        <Text className="text-white">Carregando...</Text>
      </View>
    );
  }

  return (
    <ScrollView className="flex-1 bg-neutral-800 px-4 pt-4">
      <Text className="text-2xl text-white font-bold mb-2">{movie.title}</Text>
      <Text className="text-neutral-300 mb-4">{movie.overview}</Text>

      <Text className="text-white text-lg mb-2 font-semibold">Avaliar filme</Text>

      <Controller
        control={control}
        name="name"
        render={({ field: { onChange, value } }) => (
          <TextInput
            placeholder="Seu nome"
            placeholderTextColor="#aaa"
            value={value}
            onChangeText={onChange}
            className="bg-neutral-700 text-white p-2 rounded mb-2"
          />
        )}
      />
      {errors.name && <Text className="text-red-400 mb-1">{errors.name.message}</Text>}

      <Controller
        control={control}
        name="comment"
        render={({ field: { onChange, value } }) => (
          <TextInput
            placeholder="Escreva sua avaliação"
            placeholderTextColor="#aaa"
            value={value}
            onChangeText={onChange}
            multiline
            numberOfLines={3}
            className="bg-neutral-700 text-white p-2 rounded mb-2"
          />
        )}
      />
      {errors.comment && <Text className="text-red-400 mb-1">{errors.comment.message}</Text>}

      <Button title="Enviar Avaliação" onPress={handleSubmit(onSubmit)} />

      {reviews.length > 0 ? (
        <View className="mt-6">
          <Text className="text-white text-lg font-semibold mb-2">Avaliações</Text>
          {reviews.map((rev, index) => (
            <View key={index} className="bg-neutral-700 p-3 rounded mb-2">
              <Text className="text-primary font-semibold">{rev.name}</Text>
              <Text className="text-white">{rev.comment}</Text>
            </View>
          ))}
        </View>
      ) : (
        <Text className="text-neutral-400 mt-4">Nenhuma avaliação ainda.</Text>
      )}
    </ScrollView>
  );
}
