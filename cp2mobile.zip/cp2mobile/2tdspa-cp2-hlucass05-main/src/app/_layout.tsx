import "@/global.css";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import colors from "tailwindcss/colors";

const RootLayout = () => {
  return (
    <>
      <Stack>
        <Stack.Screen name="index" options={{ headerShown: false }} />
        <Stack.Screen
          name="movie/[id]"
          options={{
            headerStyle: {
              backgroundColor: colors.neutral[800],
            },
            headerTintColor: colors.white,
          }}
        />
      </Stack>
      <StatusBar style="light" />
    </>
  );
};

export default RootLayout;
