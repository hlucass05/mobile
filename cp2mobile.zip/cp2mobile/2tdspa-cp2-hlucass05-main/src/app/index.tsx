import MovieList from "@/components/MovieList";
import MyFavorites from "@/components/MyFavorites";
import TrendingMovies from "@/components/TrendingMovies";
import {
  getTopRatedMovies,
  getTrendingMovie,
  getUpcomingMovies,
} from "@/services/movies";
import { Movie } from "@/types/movie";
import Ionicons from "@expo/vector-icons/Ionicons";
import React, { useEffect, useState } from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

const HomeScreen = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [trending, setTrending] = useState<Movie | undefined>(undefined);
  const [upcoming, setUpcoming] = useState<Movie[]>([]);
  const [topRated, setTopRated] = useState<Movie[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);

      setTrending(undefined);
      setUpcoming([]);
      setTopRated([]);

      setTrending(await getTrendingMovie());
      setUpcoming(await getUpcomingMovies(10));
      setTopRated(await getTopRatedMovies(10));

      setIsLoading(false);
    };

    fetchData();
  }, []);

  return (
    <SafeAreaView className="flex-1 bg-neutral-800">
      <View className="flex-row justify-between m-4 items-center">
        <Ionicons name="menu" size={32} color="white" />
        <Text className="text-3xl text-white font-bold">
          <Text className="text-primary">M</Text>ovies
        </Text>
        <Ionicons name="search" size={32} color="white" />
      </View>

      {isLoading && (
        <View className="flex-1 justify-center items-center">
          <ActivityIndicator size={128} className="text-primary" />
        </View>
      )}



<View className="items-center mt-4 mb-2">
  <Text className="text-white text-base">
    <Text className="text-primary font-semibold">Lucas Higuti Fontanezi</Text> — RM561120
  </Text>
</View>



      {!isLoading && (
        <ScrollView showsVerticalScrollIndicator={false}>
          <MyFavorites />
          <TrendingMovies data={trending} />
          <MovieList title="Upcoming" data={upcoming} />
          <MovieList title="Top Rated" data={topRated} />
        </ScrollView>
      )}
    </SafeAreaView>
  );
};

export default HomeScreen;
