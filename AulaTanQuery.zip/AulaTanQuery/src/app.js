import {
  View,
  Text,
  FlatList,
  ActivityIndicator,
  StyleSheet,
} from "react-native";
import { useQuery } from "@tanstack/react-query";
import { fetchUsers } from "./api/users";

export default function App() {
  //useQuery eh o hook principal do tasntack Query
  //queryKey: chave unica para identificar essa query
  // queryFn: funcao que exectua a requisicao

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["users"],
    queryFn: fetchUsers,
  });

  //exibe um spinner enquanto os dados são carregados
  if (isLoading) {
    return <ActivityIndicator size="large" style={StyleSheet.center} />;
  }

  //erro
  if (isError) {
    return (
      <View style={styles.center}>
        <Text>Erro ao buscar os dados: {error.message}</Text>
      </View>
    );
  }

  return (
    <FlatList
      data={data}
      renderItem={({ item }) => (
        <View>
          <Text style={style.name}>{item.name}</Text>
        </View>
      )}
    />
  );
}
const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  name: {
    fontWeight: "'bold",
    fontSize: 20,
  },
});
