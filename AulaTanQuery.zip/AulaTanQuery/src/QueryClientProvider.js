import { QueryClient, QueryClient, QueryClientProvider as TanstackProvider } from "@tanstack/react-query";


//Cria uma instancia do QUeryClient(controla o cach, refresh, etc)
const QueryClient = new QueryClient();

export default function QueryClientProvider({children}){
    return(
        <TanstackProvider client={QueryClient}>
            {children}
        </TanstackProvider>
    )
}