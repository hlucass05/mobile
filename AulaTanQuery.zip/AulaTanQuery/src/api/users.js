import axios from "axios"

export const fetchUsers = async ()=>{
    const response = await axios.get("https://698ddae6b79d1c928ed6c5ce.mockapi.io/users")
    return response.data; //retorna os dados (array de usuarios)
}